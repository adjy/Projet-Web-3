<?php
require_once "config.php" ;
session_start();

$logged = isset($_SESSION['nickname']) ;

require $GLOBALS['PHP_DIR']."class/Autoloader.php";
Autoloader::register();
use recette\Template ;
use recette\Donnees;
use recette\Affichages;

$gdb = new Donnees() ;
$affichage = new Affichages();

ob_start() ;

$tags = $gdb->getTagRecettes();
$listesTags = $gdb->getListesTagRecettes();
$recettesMin = $gdb->rechercheRecetteMin();

?>
    <div class="index centrer">
        <p>
            &nbsp;&nbsp;&nbsp;&nbsp;Les recettes de cuisine sont des trésors gastronomiques qui ont traversé les âges et les cultures. Que ce soit pour un plat principal, un dessert, une entrée ou un apéritif, il y a une recette pour chaque occasion et chaque palais. Chaque recette est unique, avec ses propres ingrédients, ses techniques de préparation et ses saveurs distinctes. Les recettes peuvent être transmises de génération en génération, ou partagées entre amis et membres de la famille. Que vous soyez un passionné de cuisine ou que vous cherchiez simplement à élargir votre palette culinaire, les recettes sont une source d'inspiration inépuisable pour tous les gourmets.
        </p>
        <br>
        <blockquote>"La gastronomie est l'art d'utiliser la nourriture pour créer le bonheur"
            <cite>-Theodore Zeldin</cite>
        </blockquote>
      <br>
        <header>Plongeons dans l'unvers de la cuisine. Explorez ensemble notre collection de recettes de cuisine par catégorie</header>
        <?php
        $affichage->AfficherListesCategories($tags,$gdb);
        ?>
        <header>Découvrez notre sélection de délicieuses recettes, simples à réaliser chez vous,
            pour régaler vos papilles et épater vos convives !</header>
        <?php
        $affichage->AfficherListesRecettesMin($recettesMin);
        ?>

    </div>

    <script>
        let variable = document.getElementsByClassName("etoiles")
        console.log(variable[0].children[0])

        for (let i = 0; i < variable.length; i++) {
            let variableAleatoire = Math.floor(Math.random() * 5) + 1;
            for (let j = 0; j < variable[i].children.length; j++) {
                if(variableAleatoire !== 0){
                    variable[i].children[j].style.color = "black"
                    variableAleatoire = variableAleatoire - 1;
                }
            }
        }
    </script>


<?php




$content = ob_get_clean();
$title = "The Taste Experience";
Template::render($content, $title);